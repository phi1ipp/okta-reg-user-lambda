const okta = require('@okta/okta-sdk-nodejs');

const client = new okta.Client({
    orgUrl: process.env.ORG_URL,
    token: process.env.TOKEN,
});

exports.handler = async (event) => {
    console.log(event);

    if (event.requestContext.http.method === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*'
            }
        }
    }
    const body = JSON.parse(event.body);
    const newUser = {
        profile: {
            firstName: body.fname,
            lastName: body.lname,
            email: body.email,
            login: body.login
        },
        credentials: {
            password: {
                value: body.password
            }
        }
    };

    try {
        await client.createUser(newUser);

        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*'
            },
            body: JSON.stringify('User has been created successfully'),
        };

    } catch (e) {
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*'
            },
            body: JSON.stringify('Error creating a user: ' + e)
        }
    }
};
